package MulCommSocket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	InputStream ins = null;
	OutputStream os = null;
	InputStreamReader in = null;
	Socket socket = null;
	
	
	public void startClient(String count){
		try {
			socket = new Socket("127.0.0.1", 8888);
			System.out.println("客户端" + count + "已启动...");
			//接收消息的线程
			new Thread() {
				public void run() {
					while(true) {
						try {
							ins = socket.getInputStream();
							ObjectInputStream ois = new ObjectInputStream(ins);
							Message message;
							try {
								message = (Message) ois.readObject();
								System.out.println("客户端:" + message.getId() + "发来消息\t消息内容为:" + message.getMessage());
							} catch (ClassNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}.start();
			
			//发送消息的线程
			new Thread() {
				public void run() {
					while (true) {
						try {
							os = socket.getOutputStream();
							in = new InputStreamReader(System.in);      //获取输入的消息
							String message = new BufferedReader(in).readLine();			//获取输入的消息
							 Message mes= new Message();
							 mes.setId(count);
							 mes.setMessage(message);
							 ObjectOutputStream oos = new ObjectOutputStream(os);
							 oos.writeObject(mes);
							 System.out.println("已发送！");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}.start();
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
//			try {
//				ins.close();
//				os.close();
//				in.close();
//				socket.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
	}
	
	public static void main(String[] args) {
		new Client().startClient("1");          //可以更改客户端的名字
		}
}
