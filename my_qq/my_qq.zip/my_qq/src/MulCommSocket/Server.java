package MulCommSocket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Server {
	int i = 1;
	static ArrayList<Map<String, Socket>> maps = new ArrayList<>();
	
	public void StartServer() {
		try {
			ServerSocket ss = new ServerSocket(8888);
			System.out.println("正在监听8888端口...");
			while (true) {
				Socket socket = ss.accept();
				System.out.println("客户端" + i + "已连接！");
				Map<String, Socket> map = new HashMap<>();
				map.put(String.valueOf(i), socket);
				maps.add(map);
				new Forward(map, socket).start();
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ArrayList<Map<String, Socket>> getClient(){
		return maps;
	}
	
	public static void main(String[] args) {
		new Server().StartServer();
	}

}
