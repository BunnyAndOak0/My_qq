package View;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class headPorTrait extends Window{
	public headPorTrait() {
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/headPorTrait.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root, 958, 515);
		setScene(scene);
		choseOne();
		closeIt();
		move();
		
	}
	
	public void closeIt() {
		((Button) $("submit")).setOnAction(event -> {
			this.close();
		});
	}
	
	public void choseOne() {
		ToggleGroup group = new ToggleGroup();
		((RadioButton) $("one")).setToggleGroup(group);
		((RadioButton) $("two")).setToggleGroup(group);
		((RadioButton) $("three")).setToggleGroup(group);
		((RadioButton) $("four")).setToggleGroup(group);
		((RadioButton) $("five")).setToggleGroup(group);
		((RadioButton) $("six")).setToggleGroup(group);
		((RadioButton) $("seven")).setToggleGroup(group);
		((RadioButton) $("eight")).setToggleGroup(group);
		((RadioButton) $("nine")).setToggleGroup(group);
		((RadioButton) $("ten")).setToggleGroup(group);
	}

}
