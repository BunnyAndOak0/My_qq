package View;

import java.awt.TextField;
import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.StageStyle;

public class Register extends Window{
	
	public Register(){
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/Register.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root, 600, 611);
		setScene(scene);
		setTitle("注册界面");
		initStyle(StageStyle.TRANSPARENT);
		ToggleGroup group = new ToggleGroup();
		((RadioButton) $("man")).setToggleGroup(group);
		((RadioButton) $("man")).setSelected(true);
		((RadioButton) $("woman")).setToggleGroup(group);
		move();
		setIcon();
		closeIt();
	}
	
	public void clearIt() {
		((Label) $("accountError")).setText("");
		((Label) $("nameError")).setText("");
		((Label) $("passwordError")).setText("");
		((Label) $("rePasswordError")).setText("");
		((Label) $("phoneError")).setText("");
		((Label) $("codeError")).setText("");
	}
	
	public void erroeTips(String id, String mes) {
		((Label) $(id)).setText(mes);
	}
	
	public void closeIt() {
		((Button) $("back")).setOnAction(event -> {
			this.close();
		});
	}

}
