package View;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.StageStyle;

public class HomePage extends Window{
	
	public HomePage() {
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/HomePage.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		initStyle(StageStyle.TRANSPARENT);
		Scene scene = new Scene(root, 700, 543);
		setScene(scene);
		hiddenEdit();
		editable();
		mini();
		closeIt();
		move();
	}
	
	public void closeIt() {
		((Button) $("close")).setOnAction(event -> {
			this.close();
		});
	}
	
	public void mini() {
		((Button) $("mini")).setOnAction(EventHandler -> {
			setIconified(true);
		});
	}
	
	//设置文本框不可编辑 隐藏完成按钮
	public void hiddenEdit() {
		((TextField) $("nickname")).setEditable(false);
		((TextField) $("account")).setEditable(false);
		((TextField) $("user")).setEditable(false);
		((TextField) $("birth")).setEditable(false);
		((TextField) $("address")).setEditable(false);
		((TextField) $("phone")).setEditable(false);
		((Button) $("submit")).setVisible(false);
		((Button) $("submit")).setManaged(false);
	}
	
	public void editable() {
		((Button) $("alter")).setOnAction(event -> {
			((TextField) $("nickname")).setEditable(true);
			((TextField) $("user")).setEditable(true);
			((TextField) $("birth")).setEditable(true);
			((TextField) $("address")).setEditable(true);
			((TextField) $("phone")).setEditable(true);
			((Button) $("submit")).setVisible(true);
			((Button) $("submit")).setManaged(true);
		});
	}

}
