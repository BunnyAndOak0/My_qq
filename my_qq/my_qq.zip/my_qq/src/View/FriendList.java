package View;

import java.io.IOException;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.shape.Line;
import javafx.stage.StageStyle;

public class FriendList extends Window{
	public FriendList() {
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/FriendList.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root, 320, 597);
		setIcon();
		move();
		setScene(scene);
		initStyle(StageStyle.TRANSPARENT);
		closeIt();
//		friendListShow();
		mini();
		setTitle("好友主界面");
	}
	
	public void closeIt() {
		((Button) $("quit")).setOnAction(event -> {
			this.close();
		});
		((Button) $("quit0")).setOnAction(event -> {
			this.close();
		});
	}

	public void mini() {
		((Button) $("mini")).setOnAction(event -> {
			setIconified(true);
		});
	}
//	
//	public void friendListShow() {
////		ObservableList<String> strList = FXCollections.observableArrayList("红色","黄色","绿色");
////		strList.add("黑色");
////		((ListView) $("message")).setItems(strList);
//		((ListView) $("message")).getSelectionModel().selectedIndexProperty().addListener(new ShowFriendController());
//	}
//	
//	class ShowFriendController implements ChangeListener<Object>{
//
//		@Override
//		public void changed(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
//			new MainWindow().show();
//		}
//		
//	} 
}
