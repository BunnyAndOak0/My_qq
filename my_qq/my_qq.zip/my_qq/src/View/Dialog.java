package View;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.stage.StageStyle;

//登陆界面
public class Dialog extends Window{
	
	public Dialog(){
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/Dialog.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root, 448, 397);
		initStyle(StageStyle.TRANSPARENT);
		setScene(scene);
		setTitle("qq登陆界面");
		move();
		((Button) $("mini")).setTooltip(new Tooltip("最小化"));           //设置一个提示
		((Button) $("close")).setTooltip(new Tooltip("关闭"));
		((Button) $("I_login")).setVisible(false);
		((Button) $("I_login")).setManaged(false);
		((Button) $("save_pass")).setVisible(false);
		((Button) $("save_pass")).setManaged(false);
		setLogin();
		setSavePass();
		setIcon();
		mini();
		closeit();
	}
	
	//记住密码和自动登录的选择事件响应
	public void setLogin() {
		((Button) $("I_login1")).setOnAction(event -> {
			((Button) $("I_login1")).setVisible(false);
			((Button) $("I_login1")).setManaged(false);
			((Button) $("I_login")).setVisible(true);
			((Button) $("I_login")).setManaged(true);
		});
		
		((Button) $("I_login")).setOnAction(event -> {
			((Button) $("I_login")).setVisible(false);
			((Button) $("I_login")).setManaged(false);
			((Button) $("I_login1")).setVisible(true);
			((Button) $("I_login1")).setManaged(true);
		});
	}
	
	public void setSavePass() {
		((Button) $("save_pass1")).setOnAction(event -> {
			((Button) $("save_pass1")).setVisible(false);
			((Button) $("save_pass1")).setManaged(false);
			((Button) $("save_pass")).setVisible(true);
			((Button) $("save_pass")).setManaged(true);
		});
		
		((Button) $("save_pass")).setOnAction(event -> {
			((Button) $("save_pass")).setVisible(false);
			((Button) $("save_pass")).setManaged(false);
			((Button) $("save_pass1")).setVisible(true);
			((Button) $("save_pass1")).setManaged(true);
		});
	}
	
	//关闭和清除文本
	public void closeit() {
		((Button) $("close")).setOnAction(even -> {
			this.close();
			this.clear();
		});
	}

	private void clear() {
		((TextField) $("UserName")).clear();
		((PasswordField) $("Password")).clear();
	}
	
	//实现最小化
	public void mini() {
		((Button) $("mini")).setOnAction(event -> {
			setIconified(true);
		});
	}
	
	//设置错误提示
	public void setErrorTip(String id, String Text) {
		((Label) $(id)).setText(Text);
	}

	public void resetErrorTip() {
		setErrorTip("accountError", "");
		setErrorTip("passwordError", "");
	}
	
}
