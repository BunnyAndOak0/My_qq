package View;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class Alert extends Window{
	public Alert(String account){
		try {
			root = FXMLLoader.load(getClass().getResource("FXML/Alert.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Scene scene = new Scene(root, 351, 183);
		setScene(scene);
		setTitle("提示界面！");
		((Label) $("information")).setText("您的账号为：" + account);
		closeIt();
		move();
	}

	public void closeIt() {
		((Button) $("submit")).setOnAction(event -> {
			this.close();
		});
	}
	
	public void fix(String mes) {
		((Label) $("information")).setText(mes);
	}
}
