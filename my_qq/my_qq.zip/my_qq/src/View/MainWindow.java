package View;

import java.io.IOException;

import com.mysql.jdbc.MiniAdmin;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.StageStyle;

public class MainWindow extends Window{
	public MainWindow() {
		try {
			root = FXMLLoader.load(getClass().getResource("Fxml/MainWindow.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Scene scene = new Scene(root, 638, 567);
		setScene(scene);
		initStyle(StageStyle.TRANSPARENT);
		setIcon();
		move();
		closeIt();
		mini();
	}
	
	public void closeIt() {
		((Button) $("quit1")).setOnAction(event -> {
			this.close();
		});
	}
	
	public void mini() {
		((Button) $("minimiser1")).setOnAction(event -> {
			setIconified(true);
		});
	}
}

