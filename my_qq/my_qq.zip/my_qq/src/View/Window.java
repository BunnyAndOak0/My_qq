package View;

import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public abstract class Window extends Stage{
	Parent root;          
	private double xOffset;
	private double yOffset;
	
	
	//获取图标
	public void setIcon() {
		getIcons().add(new Image(getClass().getResourceAsStream("/View/Fxml/CSS/Image/Icon/qq.gif")));
	}
	
	//设置可以移动窗口
	public void move() {
		root.setOnMousePressed(event -> {
			xOffset = getX() - event.getScreenX();
			yOffset = getY() - event.getScreenY();
//			getRoot().setCursor(Cursor.CLOSED_HAND);       //改变鼠标的样子
		});
		
		root.setOnMouseDragged(event -> {
			setX(event.getScreenX() + xOffset);
			setY(event.getScreenY() + yOffset);
		});
	}

	public Parent getRoot() {
		return root;
	}

	public void setRoot(Parent root) {
		this.root = root;
	}
	
	public Object $(String id) {
		return (Object) root.lookup("#" + id);
	}
}
