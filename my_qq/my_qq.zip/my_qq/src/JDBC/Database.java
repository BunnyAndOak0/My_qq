//package JDBC;
//
//
//
//import java.security.interfaces.RSAKey;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.spi.LocaleServiceProvider;
//
//import org.omg.PortableServer.ID_ASSIGNMENT_POLICY_ID;
//
//import Model.User;
//import View.Window;
//import javafx.collections.ObservableList;
//import javafx.scene.control.Button;
//import javafx.scene.control.TextField;
//
//public class Database {
//	Connection conn;
//	public String account;
//	public String password;
//	
//	public Database(){
//		try {
//			getConn();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	public void getConn() throws SQLException {
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//
//			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_qq?characterEncoding=utf-8", 
//					"root", "123456");
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	public void addUser(String account, String nickname, String name, String password, 
//			String birthday, String sex, String head, String address, String label, 
//			String phone, String backgorund) throws SQLException {
//		String sql = "insert into user values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//		try (PreparedStatement ps = conn.prepareStatement(sql);){
//			ps.setString(1, account);
//			ps.setString(2, nickname);
//			ps.setString(3, name);
//			ps.setString(4, password);
//			ps.setString(5, birthday);
//			ps.setString(6, sex);
//			ps.setString(7, head);
//			ps.setString(8, address);
//			ps.setString(9, label);
//			ps.setString(10, phone);
//			ps.setString(11, backgorund);
//			
//			ps.execute();
//			System.out.println("插入成功！");
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
//	
//	public boolean checkUsers(String account) {
//		String sql = "select * from user where account=?";
//		try (PreparedStatement ps = conn.prepareStatement(sql);){
//			ps.setString(1, account);
//			ResultSet rs = ps.executeQuery();
//			if (rs.next()) {
//				return false;
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return true;
//	}
//	
//	public boolean checkUser(User user, String account, String password) {
//		String sql = "select * from user where account=? and password=?";
//		try (PreparedStatement ps = conn.prepareStatement(sql);){
//			ps.setString(1, account);
//			ps.setString(2, password);
//			ResultSet rs = ps.executeQuery();
//			if (rs.next()) {
//				user.setName(rs.getString(3));
//				user.setHead(rs.getString(7));
//				return true;
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	public void addSaveUser(String account, String password, String head) {
//		String sql1 = "select * from save_pass where account=? and password=?";
//		try (PreparedStatement ps1 = conn.prepareStatement(sql1);){
//			ps1.setString(1, account);
//			ps1.setString(2, password);
//			ResultSet rs = ps1.executeQuery();
//			if (rs.next()) {
//				String sql3 = "insert into dialog values(?)";
//				addDatabse(sql3, account);
//			}else {
//				String sql2 = "insert into save_pass values(?, ?, ?)";
//				String sql3 = "insert into dialog values(?)";
//				addDatabse(sql2, account, password, head);
//				addDatabse(sql3, account);
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	public void addDatabse(String sql, String... date ) throws SQLException {
//		PreparedStatement ps2 = conn.prepareStatement(sql);
//		for (int i = 0; i < date.length; i++) {
//			ps2.setString(i + 1,  date[i]);
//		}
//		ps2.execute();
//	}
//	
//	public boolean checkSave() {
//		String sql = "select * from dialog";
//		try {
//			ResultSet rs = conn.prepareStatement(sql).executeQuery();
//			if (rs.next()) {
//				account = rs.getString(1);
//				String sql1 = "select * from save_pass where account=?";
//				PreparedStatement ps1 = conn.prepareStatement(sql1);
//				ps1.setString(1, account);
//				ResultSet rs1 = ps1.executeQuery();
//				if (rs1.next()) {
//					password = rs1.getString("password");
//				}
//				return true;
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	public void deleteSave() {
//		String sql = "delete from dialog";
//		try (PreparedStatement ps = conn.prepareStatement(sql);){
//			ps.execute();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	public User checkUser(String username) {
//		User user = new User();
//		
//		String sql = "select * from user where account=?";
//		try(PreparedStatement ps = conn.prepareStatement(sql)) {
//			ps.setString(1, username);
//			ResultSet rs = ps.executeQuery();
//			if (rs.next()) {
//				user.setAccount(rs.getString("account"));
//				user.setName(rs.getString("name"));
//				user.setNickname(rs.getString("nickname"));
//				user.setBirthday(rs.getString("birthday"));
//				user.setAddress(rs.getString("address"));
//				user.setPhone(rs.getString("phone"));
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return user;
//	}
//	
//	public void updateUser(String... dates) throws Exception{
//		String sql = "update user set nickname=?, name=?, birthday=?, address=?, phone=? where account=?";
//		PreparedStatement ps = conn.prepareStatement(sql);
//		for (int i = 0; i < dates.length; i++) {
//			ps.setString(i + 1, dates[i]);
//		}                                                                  
//		ps.executeUpdate();
//	}
//	
//	public ObservableList<String> listFriend(ObservableList<String> list, String account){
//		String sql = "select * from companion where I_account=?";
//		try (PreparedStatement ps = conn.prepareStatement(sql);){
//			ps.setString(1, account);
//			ResultSet rs = ps.executeQuery();
//			if (rs.next()) {
//				String y_account = rs.getString("remark");
//				list.add(y_account);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return list;
//	}
//	
//	public ResultSet checkAll(String sql, String... datas) {
//		try {
//			PreparedStatement ps = conn.prepareStatement(sql);
//			for (int i = 0; i < datas.length; i++) {
//				ps.setString(i+1, datas[i]);
//			}
//			ResultSet rs = ps.executeQuery();
//			if (rs.next()) {
//				return rs;
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//	}
//	
//	public void closeConnect() {
//		if (conn != null) {
//			try {
//				conn.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
//}

package JDBC;

import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.spi.LocaleServiceProvider;

import org.omg.PortableServer.ID_ASSIGNMENT_POLICY_ID;

import Model.User;
import View.Window;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Database {
	Connection conn;
	public String account;
	public String password;
	
	public Database(){
		
	}
	
	public Connection getConn() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_qq?characterEncoding=utf-8", 
					"root", "123456");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public void addUser(String account, String nickname, String name, String password, 
			String birthday, String sex, String head, String address, String label, 
			String phone, String backgorund) throws SQLException {
		String sql = "insert into user values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setString(1, account);
			ps.setString(2, nickname);
			ps.setString(3, name);
			ps.setString(4, password);
			ps.setString(5, birthday);
			ps.setString(6, sex);
			ps.setString(7, head);
			ps.setString(8, address);
			ps.setString(9, label);
			ps.setString(10, phone);
			ps.setString(11, backgorund);
			
			ps.execute();
			System.out.println("插入成功！");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public boolean checkUsers(String account) {
		String sql = "select * from user where account=?";
		try (Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setString(1, account);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean checkUser(User user, String account, String password) {
		String sql = "select * from user where account=? and password=?";
		try (Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setString(1, account);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user.setName(rs.getString(3));
				user.setHead(rs.getString(7));
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public void addSaveUser(String account, String password, String head) {
		String sql1 = "select * from save_pass where account=? and password=?";
		try (Connection conn = getConn();
			PreparedStatement ps1 = conn.prepareStatement(sql1);){
			ps1.setString(1, account);
			ps1.setString(2, password);
			ResultSet rs = ps1.executeQuery();
			if (rs.next()) {
				String sql3 = "insert into dialog values(?)";
				addDatabse(sql3, account);
			}else {
				String sql2 = "insert into save_pass values(?, ?, ?)";
				String sql3 = "insert into dialog values(?)";
				addDatabse(sql2, account, password, head);
				addDatabse(sql3, account);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addDatabse(String sql, String... date ){
		try (Connection conn = getConn();
			PreparedStatement ps2 = conn.prepareStatement(sql);){
				for (int i = 0; i < date.length; i++) {
					ps2.setString(i + 1,  date[i]);
				}
				ps2.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean checkSave() {
		String sql = "select * from dialog";
		try(Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);) {
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				account = rs.getString(1);
				String sql1 = "select * from save_pass where account=?";
				PreparedStatement ps1 = conn.prepareStatement(sql1);
				ps1.setString(1, account);
				ResultSet rs1 = ps1.executeQuery();
				if (rs1.next()) {
					password = rs1.getString("password");
				}
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public void deleteSave() {
		String sql = "delete from dialog";
		try (Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public User checkUser(String username) {
		User user = new User();
		
		String sql = "select * from user where account=?";
		try(Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user.setAccount(rs.getString("account"));
				user.setName(rs.getString("name"));
				user.setNickname(rs.getString("nickname"));
				user.setBirthday(rs.getString("birthday"));
				user.setAddress(rs.getString("address"));
				user.setPhone(rs.getString("phone"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public void updateUser(String... dates){
		String sql = "update user set nickname=?, name=?, birthday=?, address=?, phone=? where account=?";
		try(Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);) {
			for (int i = 0; i < dates.length; i++) {
				ps.setString(i + 1, dates[i]);
			}                                                                  
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ObservableList<String> listFriend(ObservableList<String> list, String account){
		String sql = "select * from companion where I_account=?";
		try (Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setString(1, account);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String y_account = rs.getString("remark");
				list.add(y_account);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public ResultSet checkAll(String sql, String... datas) {
		try(Connection conn = getConn();
			PreparedStatement ps = conn.prepareStatement(sql);) {
			for (int i = 0; i < datas.length; i++) {
				ps.setString(i+1, datas[i]);
			}
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return rs;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}

