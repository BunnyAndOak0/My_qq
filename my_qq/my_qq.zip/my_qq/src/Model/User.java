package Model;

public class User {
	private String account;
	private String nickname;
	private String name;
	private String password;
	private String birthday;
	private String sex;
	private String head;
	private String address;
	private String label;
	private String phone;
	private String background;
	
	public User() {
		
	}
	
	public void setAll(String account, String nickname, String name, String password, String birthday, String sex, String head,
			String address, String label, String phone, String background) {
		this.account = account;
		this.nickname = nickname;
		this.name = name;
		this.password = password;
		this.birthday = birthday;
		this.sex = sex;
		this.head = head;
		this.address = address;
		this.label = label;
		this.phone = phone;
		this.background = background;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

}
