package Socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Map;

//转发
public class Forward extends Thread{
	Map<Integer, Socket> map = null;
	Socket socket = null;
	
	public Forward(Map<Integer, Socket> map, Socket socket) {
		 this.map = map;
		 this.socket = socket;
	}
	
	public void run(){
		try {
			InputStream is = socket.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(is);
			while (true) {
				Message message;
				try {
					message = (Message) ois.readObject();
					System.out.println("客户端" + message.getId() + "发来消息         内容为：" + message.getMessage());
					
					OutputStream os = map.get(message.getDesId()).getOutputStream();
					ObjectOutputStream oos = new ObjectOutputStream(os);
					oos.writeObject(message);
					System.out.println("已转发！");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
