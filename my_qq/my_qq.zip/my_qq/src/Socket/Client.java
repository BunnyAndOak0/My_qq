package Socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	String desId;
	
	public Client(String count) {
		try {
			Socket socket = new Socket("127.0.0.1", 8888);
			System.out.println("客户端" + count + "已启动！");
			//接收消息
			new Thread() {
				public void run() {
					try {
						while (true) {
							InputStream is = socket.getInputStream();
							ObjectInputStream ois = new ObjectInputStream(is);
							try {
								Message message = (Message) ois.readObject();
								System.out.println("接收到的消息为：" + message.getMessage());
								desId = message.getId();
								System.out.println(desId);
							} catch (ClassNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}.start();

			//发送消息
			OutputStream os;
			try {
				os = socket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);
				InputStreamReader ins = new InputStreamReader(System.in);
				while (true) {
					Message message = new Message();
					String mes;
					mes = new BufferedReader(ins).readLine();
					message.setId(count);
					message.setDesId("123");
					message.setMessage(mes);
					oos.writeObject(message);
					System.out.println("已发送!");
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//	public static void main(String[] args) {
//		new Client(2);
//	}

}
