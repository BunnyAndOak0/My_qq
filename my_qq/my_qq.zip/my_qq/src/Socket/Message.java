package Socket;

import java.io.Serializable;

public class Message implements Serializable{
	String id;
	String desId;
	String message;
	
	public String getMessage() {
		return message;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDesId() {
		return desId;
	}
	public void setDesId(String desId) {
		this.desId = desId;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
