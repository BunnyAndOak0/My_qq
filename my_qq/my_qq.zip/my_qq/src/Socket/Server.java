package Socket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server {
	public void startServer() {
		try {
			ServerSocket ss = new ServerSocket(8888);
			System.out.println("服务端已启动，正在监听8888...");
			int count = 1;
			Map<Integer, Socket> map = new HashMap<Integer, Socket>();
			
			while (true) {
				Socket socket = ss.accept();
				System.out.println("客户端" + count + "已启动！");
				map.put(count, socket);
				new Forward(map, socket).start();
				count++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new Server().startServer();
	}
}
