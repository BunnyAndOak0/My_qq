package Controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import com.sun.jna.platform.win32.Advapi32Util.Account;

import JDBC.Database;
import Model.User;
import Socket.Client;
import View.Alert;
import View.Dialog;
import View.FriendList;
import View.HomePage;
import View.MainWindow;
import View.Register;
import View.Window;
import View.headPorTrait;
import View.homePage;
import View.mainWindow;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Controller {
	Dialog dialog = new Dialog();
	Register register = new Register();
	Database database = new Database();
	Alert alert;
	headPorTrait headTrait = new headPorTrait();
	User user = new User();
	FriendList friendList = new FriendList();
	HomePage homePage = new HomePage();
	MainWindow mainWindow = new MainWindow();
	
	public Object $(Window window, String id) {
		return (Object)window.getRoot().lookup("#" + id);
	}
	
	public void init() throws IOException {
		dialog.show();
		login();
		regitserControllers();
		firendListControllers();
		changeHead();
		mainWindowController();
		if (database.checkSave()) {
			((Button) $(dialog, "save_pass")).setVisible(true);
			((Button) $(dialog, "save_pass")).setManaged(true);
			((Button) $(dialog, "save_pass1")).setVisible(true);
			((Button) $(dialog, "save_pass1")).setManaged(true);
			((TextField) $(dialog, "UserName")).setText(database.account);     //从数据库中查找数据
			((PasswordField) $(dialog, "Password")).setText(database.password);
		}
	}
	
	public void regitserControllers() {
		registerExec();
		registerController();
	}
	
	public void firendListControllers() {
		friendListContrller();
	}
	
	public void mainWindowController() {
//		mainConnect();
	}
	
	//点击注册按钮跳转至注册按钮
	public void  registerExec() {
			((Button) $(dialog, "register")).setOnAction(event -> {
				register.show();
			});
		}
	
		//点击注册按钮后的控制效果
	public void registerController() {
		((Button) $(register, "register")).setOnAction(event -> {
			register.clearIt();
			String nickname = ((TextField) $(register, "account")).getText();
			String name = ((TextField) $(register, "name")).getText();
			String password = ((TextField) $(register, "password")).getText();
			String rePassword = ((TextField) $(register, "rePassword")).getText();
			String phone = ((TextField) $(register, "phone")).getText();
			String code = ((TextField) $(register, "codeText")).getText();
			String birthday = null;
			String sex = "男";
			//获取生日      还有点问题！！！
//			ZoneId zoneId = ZoneId.systemDefault();
//            LocalDate localDate = ((DatePicker) $(register,"birthday")).getValue();
//            ZonedDateTime zdt = localDate.atStartOfDay(zoneId);
//            Date date = Date.from(zdt.toInstant());
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//            String birthday = sdf.format(date);
            
			//正则校验
			String accountRegExp = "^[0-9,a-z,A-Z,\\u4e00-\\u9fa5]{1,15}$";  //正则匹配：只能输入汉字，数字，字母，长度1-15
            String nameRegExp = "^[a-z,A-Z,\\u4e00-\\u9fa5]{1,100}$";  //正则匹配：只能输入汉字，字母，长度1-100
            String phoneRegExp = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$"; //正则匹配：只能是正常的电话号码
            String passwordRegExp = "^[a-z,A-Z,0-9]{6,20}$";  //6-20位的数字或者字母
            String rePasswordRegExp = "^[a-z,A-Z,0-9]{6,20}$";  //6-20位的数字或者字母
            
            if (nickname.equals("") || name.equals("") || password.equals("") || rePassword.equals("") || 
            		phone.equals("") || code.equals("")){
            	if (nickname.equals("")) {
					register.erroeTips("accountError", "姓名不能为空！");
				}
            	if (name.equals("")) {
					register.erroeTips("nameError", "昵称不能为空！");
				}
            	if (password.equals("")) {
					register.erroeTips("passwordError", "密码不能为空！");
				}
            	if (rePassword.equals("")) {
					register.erroeTips("rePasswordError", "请输入密码");
				}
//            	if (birthday.equals("")) {
//					register.erroeTips("birthdayError", "出生日期不能为空！");
//				}
            	if (phone.equals("")) {
					register.erroeTips("phoneError", "电话号码不能为空！");
				}
            	if (code.equals("")) {
					register.erroeTips("codeError", "验证码不能为空！");
				}
			}else if(!(nickname.matches(accountRegExp)) || !(name.matches(nameRegExp)) || !(password.matches(passwordRegExp)) ||
					!(rePassword.matches(rePassword)) || !(phone.matches(phoneRegExp))) {
				if (!(nickname.matches(accountRegExp))) {
					register.erroeTips("accountError", "只能输入长度1-15的汉字，数字，字母");
				}
				if (!(name.matches(nameRegExp))) {
					register.erroeTips("nameError", "只能输入长度1-15的汉字，数字，字母");
				}
				if (!(password.matches(passwordRegExp))) {
					register.erroeTips("passwordError", "只能输入长度6-20的数字，字母");
				}
				if (!(rePassword.matches(rePasswordRegExp))) {
					register.erroeTips("rePasswordError", "只能输入长度6-20的数字，字母");
				}
				if (!(rePassword.equals(password))) {
					register.erroeTips("rePasswordError", "两次密码输入不一致");
				}
			
				if (!(phone.matches(phoneRegExp))) {
					register.erroeTips("phoneError", "电话号码格式不正确");
				}
			}else {       //代表数据没问题    可以加入数据库
				String account = (int)((Math.random() * 9 + 1) * 10000000) + "";
				if (database.checkUsers(account)) {
					if (!(((RadioButton) $(register, "man")).isSelected())) {
						sex = "女";
					}
					try {
						user.setAll(account, nickname, name, password, null, sex, user.getHead(), 
								"云南省昆明市", null,phone, "background6");
						database.addUser(account, nickname, name, password, null, sex, user.getHead(), 
								"云南省昆明市", null,phone, "background6");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					alert = new Alert(account);
					alert.show();
					register.close();
				}else {
					//注册失败！
					register.erroeTips("codeError", "注册失败！");
				}
			}
		});
		
		((Button) $(register, "ChooseHead")).setOnAction(event -> {
			headTrait.show();
		});
		
	}
	
	//更改头像的控制
	public void changeHead() {
		((Button) $(headTrait, "submit")).setOnAction(event -> {
			if (((RadioButton) $(headTrait, "one")).isSelected()) {
				user.setHead("one");
			}else if(((RadioButton) $(headTrait, "two")).isSelected()) {
				user.setHead("two");
			}if (((RadioButton) $(headTrait, "three")).isSelected()) {
				user.setHead("three");
			}else if(((RadioButton) $(headTrait, "four")).isSelected()) {
				user.setHead("for");
			}if (((RadioButton) $(headTrait, "five")).isSelected()) {
				user.setHead("five");
			}else if(((RadioButton) $(headTrait, "six")).isSelected()) {
				user.setHead("six");
			}if (((RadioButton) $(headTrait, "seven")).isSelected()) {
				user.setHead("seven");
			}else if(((RadioButton) $(headTrait, "eight")).isSelected()) {
				user.setHead("eight");
			}if (((RadioButton) $(headTrait, "nine")).isSelected()) {
				user.setHead("nine");
			}else if(((RadioButton) $(headTrait, "ten")).isSelected()) {
				user.setHead("ten");
			}
			((Button) $(register, "HeadPortrait")).setStyle(String.format("-fx-background-image:url('/View/Fxml/CSS/Image/head/%s.jpg')", user.getHead()));
			headTrait.close();
		});
	}
	
	public void login() {
		((Button) $(dialog, "enter")).setOnAction(event -> {
			String account = ((TextField) $(dialog, "UserName")).getText();
			String password = ((TextField) $(dialog, "Password")).getText();
			user = database.checkUser(((TextField) $(dialog, "UserName")).getText());
			if (database.checkUser(user, account, password)) {
				((Label) $(friendList, "myAccount")).setText(user.getNickname());
				//头像加载暂时有问题
				((Button) $(friendList, "myHead")).setStyle(String.format("-fx-background-image:url"
						+ "('/View/Fxml/CSS/Image/head/%s.jpg')",
						user.getHead()));
				
				//设置记住密码等操作
				if (((Button) $(dialog, "save_pass")).isVisible()) {
					database.addSaveUser(account, password, user.getHead());
				}else {
					database.deleteSave();
				}
				
				new Client(account);        //不知道为什么界面会死掉
				
				showFirendList();
				friendList.show();
				dialog.close();
			}else {
				alert = new Alert(account);
				alert.fix("用户名或者密码错误！");
				alert.show();
			}
		});
	}
	
	public void friendListContrller(){
		((Button) $(friendList, "myHead")).setOnAction(event -> {
			homePage.show();
			try {
				editInfo();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}
	
	public void editInfo() throws Exception {
		((TextField) $(homePage, "account")).setText(user.getAccount());
		((TextField) $(homePage, "nickname")).setText(user.getNickname());
		((TextField) $(homePage, "user")).setText(user.getName());
		((TextField) $(homePage, "birth")).setText(user.getBirthday());
		((TextField) $(homePage, "address")).setText(user.getAddress());
		((TextField) $(homePage, "phone")).setText(user.getPhone());
		
		((Button) $(homePage, "submit")).setOnAction(event -> {
			((TextField) $(homePage, "account")).setEditable(false);
			((TextField) $(homePage, "user")).setEditable(false);
			((TextField) $(homePage, "birth")).setEditable(false);
			((TextField) $(homePage, "address")).setEditable(false);
			((TextField) $(homePage, "phone")).setEditable(false);
			((Button) $(homePage, "submit")).setVisible(false);
			((Button) $(homePage, "submit")).setManaged(false);
			
			try {
				database.updateUser(((TextField) $(homePage, "nickname")).getText(), ((TextField) $(homePage, "user")).getText(),
						((TextField) $(homePage, "birth")).getText(), ((TextField) $(homePage, "address")).getText(), 
						((TextField) $(homePage, "phone")).getText(), ((TextField) $(homePage, "account")).getText()
						);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			((Label) $(friendList, "myAccount")).setText(((TextField) $(homePage, "nickname")).getText());
		});
	}
	
	public void showFirendList() {
		ObservableList<String> list = FXCollections.observableArrayList();
		((ListView) $(friendList, "message")).setItems(database.listFriend(list, user.getAccount()));
		((ListView) $(friendList, "message")).getSelectionModel().selectedIndexProperty().addListener(new changeListerner());
	}
	
	class changeListerner implements ChangeListener<Object>{
		@Override
		public void changed(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
			String sql = "select * from companion where I_account=?";
			ResultSet rs = database.checkAll(sql, user.getAccount());
			try {
				((Button) $(mainWindow, "friendMore")).setText(rs.getString("remark"));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mainWindow.show();
		}
	}
	
}
