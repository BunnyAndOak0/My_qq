package Main;

import Controller.Controller;
import View.FriendList;
import javafx.application.Application;
import javafx.stage.Stage;

public class main extends Application{

	@Override
	public void start(Stage window) throws Exception {
		// TODO  Auto-generated method stub
		new Controller().init();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
